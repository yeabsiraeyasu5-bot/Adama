PHONE: Extract this folder/ZIP, then open index.html in Chrome.
The website is self-contained and does not need the other files.
